"""
Token Flight package for generating and managing Ergo transactions.
"""

__version__ = "0.1.0" 